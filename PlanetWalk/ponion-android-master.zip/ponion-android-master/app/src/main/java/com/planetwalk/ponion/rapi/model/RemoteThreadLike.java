package com.planetwalk.ponion.rapi.model;

public class RemoteThreadLike {
    public Long tid;

    public Integer kind;

    public String extra;

    public Long count;
}
