package com.planetwalk.ponion.rapi.model;

public class EmojiComment {
    // "kind":7,"name":"诈唬，骗人"
    public Integer kind;
    public String name;
}
