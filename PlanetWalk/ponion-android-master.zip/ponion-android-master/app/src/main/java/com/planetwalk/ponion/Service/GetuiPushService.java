package com.planetwalk.ponion.Service;

import com.igexin.sdk.PushService;

public class GetuiPushService extends PushService {

}
