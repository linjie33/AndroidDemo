package com.planetwalk.ponion.rapi.model;

public class MediaStore {
    public String origin;
    public String target;
    public long timestamp;
    public String contentType;
    public long size;
}