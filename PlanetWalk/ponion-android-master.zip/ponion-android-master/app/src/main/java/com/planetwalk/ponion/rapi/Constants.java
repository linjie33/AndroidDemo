package com.planetwalk.ponion.rapi;

public class Constants {
    public static final String PONION_BASE_URL = "http://planetwalk.top:8096";
    public static final String PLANETWALK_BASE_URL = "http://planetwalk.top:8097";
}
